
function saveCharacter() {
    const name = document.getElementById('name').value;
    const description = document.getElementById('description').value;
    const strength = document.getElementById('strength').value;
    const attack = document.getElementById('attack').value;
    const intelligence = document.getElementById('intelligence').value;
    const speed = document.getElementById('speed').value;
    const energy = document.getElementById('energy').value;
    const skills = document.getElementById('skills').value.split(',');
    const imageFile = document.getElementById('image').files[0];

    if (!name) return alert('Wprowadź imię postaci.');

    const reader = new FileReader();
    reader.onload = function() {
        const imageData = reader.result;

        const character = {
            name, description, strength, attack, intelligence, speed, energy, skills, imageData
        };

        let characters = JSON.parse(localStorage.getItem('characters') || '[]');
        characters.push(character);
        localStorage.setItem('characters', JSON.stringify(characters));
        displayCharacters();
    };

    if (imageFile) {
        reader.readAsDataURL(imageFile);
    } else {
        reader.onload();
    }
}

function displayCharacters() {
    const container = document.getElementById('characters');
    container.innerHTML = '';
    const characters = JSON.parse(localStorage.getItem('characters') || '[]');
    characters.forEach(c => {
        const card = document.createElement('div');
        card.className = 'character-card';
        card.innerHTML = \`
            <h3>\${c.name}</h3>
            <p><strong>Opis:</strong> \${c.description}</p>
            <p>Siła: \${c.strength}, Atak: \${c.attack}, Inteligencja: \${c.intelligence}, Prędkość: \${c.speed}, Energia: \${c.energy}</p>
            <p><strong>Umiejętności:</strong> \${c.skills.join(', ')}</p>
            \${c.imageData ? '<img src="' + c.imageData + '" width="100">' : ''}
        \`;
        container.appendChild(card);
    });
}

function toggleTheme() {
    document.body.classList.toggle('dark');
}

window.onload = displayCharacters;
